#! /bin/sh
### BEGIN INIT INFO
# Provides:          firewall-ng.sh
# Required-Start:    $all
# Required-Stop:
# Default-Start:     2 3 4 5
# Default-Stop:
# Short-Description: Run Firewall-ng /etc/init.d/rc.firewall
### END INIT INFO


PATH=/sbin:/usr/sbin:/bin:/usr/bin

. /lib/init/vars.sh
. /lib/lsb/init-functions

do_start() {
	if [ -x /etc/init.d/rc.firewall ]; then
	        [ "$VERBOSE" != no ] && log_begin_msg "Running Firewall-ng (/etc/init.d/rc.firewall)"
/etc/init.d/rc.firewall start
		ES=$?
		[ "$VERBOSE" != no ] && log_end_msg $ES
		return $ES
	fi
}

case "$1" in
    start)
	do_start
        ;;
    restart|reload|force-reload)
        echo "Error: argument '$1' not supported" >&2
        exit 3
        ;;
    stop|status)
/etc/init.d/rc.firewall stop
        ;;
    *)
        echo "Usage: $0 start|stop" >&2
        exit 3
        ;;
esac
