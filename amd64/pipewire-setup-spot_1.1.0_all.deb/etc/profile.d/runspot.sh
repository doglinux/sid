#!/bin/bash

#if [ $(id -u) != 0 ]; then
export XDG_RUNTIME_DIR=/run/user/$(id -u)
	if [ ! -d ${XDG_RUNTIME_DIR} ] ; then
	mkdir -p ${XDG_RUNTIME_DIR}
	chmod 0700 ${XDG_RUNTIME_DIR}
	chown ${USER} ${XDG_RUNTIME_DIR}
	fi
#fi

  if [ $(id -u) = 0 ]; then
SPOT_HOME=$(awk -F: '$1=="spot" {print $6}' /etc/passwd)
if [ -n "$SPOT_HOME" ]; then
XUSER=spot
else   # add user spot

XUSER=spot
adduser --disabled-password --shell /bin/bash --gecos ",,," ${XUSER}
usermod -a -G audio,sudo,video,plugdev,cdrom,disk ${XUSER}
fi


IDU=$(id -u ${XUSER}) 
export PULSE_SERVER=unix:/run/user/${IDU}/pulse/native
export PULSE_COOKIE=/home/${XUSER}/.config/pulse/cookie
  fi

